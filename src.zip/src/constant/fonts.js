const AppFonts = {
    regular: "Raleway-Regular",
    bold: "Raleway-Bold",
    medium: "Raleway-Medium",
    Bolditalic: "Raleway-BoldItalic",
    ExtraBold: "Raleway-ExtraBold",
    Semibold: "Raleway-SemiBold",
    Sourceregular: "SourceSansPro-Regular",
    light: "Raleway-Light",
    Semibolditalic: "Raleway-SemiBoldItalic",
    sansRegular: "OpenSans-Regular"
}
export default AppFonts;