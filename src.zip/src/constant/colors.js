const appColors = {
    black: "#000000",
    white: "#FFFFFF",
    textcolor:"#F1F1F1",
    blue:"#0096FF",
    borderColor:"#EFF9FF",
grey:"grey"

}

export default appColors;